#!/bin/sh
docker build --no-cache -t swidzinski/cmake:examples -f Dockerfile.examples .
