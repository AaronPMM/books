#include "car.h"
std::string Car::honk() {
  return "beep beep";
};
