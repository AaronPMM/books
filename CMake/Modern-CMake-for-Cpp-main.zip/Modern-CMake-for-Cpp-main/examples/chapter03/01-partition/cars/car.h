#include <string>
class Car {
  public:
    std::string honk();
};
