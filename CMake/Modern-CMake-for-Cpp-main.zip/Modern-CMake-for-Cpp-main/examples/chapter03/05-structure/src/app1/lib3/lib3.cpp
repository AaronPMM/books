#include "lib3.h"
std::string Lib3::method() {
  return "Lib3::method()";
};
