#include <string>
class Lib3 {
  public:
    std::string method();
};
