#include "lib1.h"
std::string Lib1::method() {
  return "Lib1::method()";
};
