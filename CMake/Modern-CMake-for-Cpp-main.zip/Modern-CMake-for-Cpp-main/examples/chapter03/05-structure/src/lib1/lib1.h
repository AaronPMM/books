#include <string>
class Lib1 {
  public:
    std::string method();
};
