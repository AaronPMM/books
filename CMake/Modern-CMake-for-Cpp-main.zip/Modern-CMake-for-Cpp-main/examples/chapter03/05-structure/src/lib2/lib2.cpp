#include "lib2.h"
std::string Lib2::method() {
  return "Lib2::method()";
};
