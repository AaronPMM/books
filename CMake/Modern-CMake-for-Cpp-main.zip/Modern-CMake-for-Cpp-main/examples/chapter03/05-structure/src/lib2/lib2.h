#include <string>
class Lib2 {
  public:
    std::string method();
};
