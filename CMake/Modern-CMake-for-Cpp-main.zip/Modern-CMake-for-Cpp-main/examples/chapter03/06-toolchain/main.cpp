#include <iostream>

int main() {
  std::cout << "This is a very advanced software." << std::endl;
  return 0;
}
