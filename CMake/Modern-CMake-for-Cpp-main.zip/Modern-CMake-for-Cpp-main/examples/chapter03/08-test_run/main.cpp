#include <iostream>

int main()
{
    std::cout << "Quick check if things work." << std::endl;
}
