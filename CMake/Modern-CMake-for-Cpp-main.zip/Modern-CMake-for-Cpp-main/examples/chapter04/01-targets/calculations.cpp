#include "calculations.h"
int complexCalculations(int a, int b) {
    return a+b;
};
