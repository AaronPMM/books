int complexCalculations(int a, int b);
