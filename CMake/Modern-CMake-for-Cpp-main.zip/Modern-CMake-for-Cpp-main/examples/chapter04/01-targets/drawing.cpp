#include "drawing.h"
#include <iostream>
void drawChart() {
    std::cout << "Drawing a chart" << std::endl;
};
