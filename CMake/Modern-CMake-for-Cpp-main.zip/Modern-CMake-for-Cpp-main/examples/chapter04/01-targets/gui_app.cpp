#include "calculations.h"
#include "drawing.h"
#include <iostream>

int main() {
  std::cout << complexCalculations(2, 2) << std::endl;
  drawChart();
  return 0;
}
