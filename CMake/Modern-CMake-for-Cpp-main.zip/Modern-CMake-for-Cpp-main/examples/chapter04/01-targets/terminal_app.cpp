#include "calculations.h"
#include <iostream>

int main() {
  std::cout << complexCalculations(2, 2) << std::endl;
  return 0;
}
