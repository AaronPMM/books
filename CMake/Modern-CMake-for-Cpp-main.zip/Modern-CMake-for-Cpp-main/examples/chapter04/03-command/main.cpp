#include <iostream>
#include "constants.h"

int main() {
  std::cout << CONSTANT(It works) << std::endl;
  return 0;
}
