#include <iostream>

void show_gui() {
  std::cout << "A Linux GUI." << std::endl;
}
