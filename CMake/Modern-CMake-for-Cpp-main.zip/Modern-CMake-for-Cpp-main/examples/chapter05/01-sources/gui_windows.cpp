#include <iostream>

void show_gui() {
  std::cout << "A Windows GUI." << std::endl;
}
