#include <iostream>

using namespace std;
void func() {
  for(int i = 0; i < 3; i++)
    cout << "hello\n";
}

int main() {
  func();
}
