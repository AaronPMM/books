#include <iostream>

void function_a() {
  std::cout << "function A" << std::endl;
}
