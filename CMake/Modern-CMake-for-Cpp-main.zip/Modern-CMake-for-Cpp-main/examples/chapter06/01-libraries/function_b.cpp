#include <iostream>

void function_b() {
  std::cout << "function B" << std::endl;
}
