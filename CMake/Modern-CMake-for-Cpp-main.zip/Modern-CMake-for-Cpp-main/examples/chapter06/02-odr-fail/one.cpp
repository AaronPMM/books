#include <iostream>
#include "shared.h"

int main() {
  std::cout << i << std::endl;
}
