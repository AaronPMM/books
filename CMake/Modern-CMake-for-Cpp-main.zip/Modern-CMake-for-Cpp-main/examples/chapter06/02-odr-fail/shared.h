int i;
