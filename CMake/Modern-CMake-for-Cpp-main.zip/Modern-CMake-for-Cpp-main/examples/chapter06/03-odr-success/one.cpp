#include <iostream>
#include "shared.h"

int main() {
  std::cout << shared::i << std::endl;
}
