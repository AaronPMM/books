struct shared {
  static inline int i = 1;
};
