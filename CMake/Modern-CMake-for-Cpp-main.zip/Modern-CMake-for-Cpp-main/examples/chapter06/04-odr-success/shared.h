static int i;
