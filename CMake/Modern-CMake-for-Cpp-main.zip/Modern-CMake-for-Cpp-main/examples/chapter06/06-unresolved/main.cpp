#include <iostream>
extern int a;
int main() {
  std::cout << a << std::endl;
}
