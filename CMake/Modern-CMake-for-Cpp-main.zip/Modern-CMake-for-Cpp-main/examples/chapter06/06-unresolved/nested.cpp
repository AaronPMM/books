int b = 123;
