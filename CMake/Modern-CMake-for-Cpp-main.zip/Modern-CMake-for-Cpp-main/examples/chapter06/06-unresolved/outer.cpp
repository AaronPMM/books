extern int b;
int a = b;
