extern int start_program(int, const char**);
int main(int argc, const char** argv) {
  return start_program(argc, argv);
}
