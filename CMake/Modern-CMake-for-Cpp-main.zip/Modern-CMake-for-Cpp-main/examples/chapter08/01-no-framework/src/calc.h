#pragma once

class Calc {
 public:
   int Sum(int a, int b);
   int Multiply(int a, int b);
};
