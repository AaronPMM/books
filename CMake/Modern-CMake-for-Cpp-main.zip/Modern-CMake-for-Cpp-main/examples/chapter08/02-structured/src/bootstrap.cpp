int run(); // declaration
int main() {
  run();
}
