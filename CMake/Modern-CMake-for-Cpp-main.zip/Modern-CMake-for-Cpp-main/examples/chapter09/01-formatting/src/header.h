int unused() {
  return 2 + 2;
}
