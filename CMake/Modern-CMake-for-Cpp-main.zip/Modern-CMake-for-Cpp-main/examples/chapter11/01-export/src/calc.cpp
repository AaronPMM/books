int Sum(int a, int b) {
  return a + b;
}

int Multiply(int a, int b) {
  return a * b;
}
