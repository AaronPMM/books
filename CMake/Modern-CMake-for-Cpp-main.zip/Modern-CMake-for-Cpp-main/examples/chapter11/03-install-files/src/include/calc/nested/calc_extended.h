#pragma once

int Subtract(int a, int b) {
  return a - b;
}

int Divide(int a, int b) {
  return a / b;
}
