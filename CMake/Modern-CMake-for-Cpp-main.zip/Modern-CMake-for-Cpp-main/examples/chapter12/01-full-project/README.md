# Calc Console

Calc Console is a calculator that adds two numbers in a
terminal. It does all the math by using a **Calc** library.
This library is also available in this package.

This application is written in C++ and built with CMake.

## More information

- Installation instructions are in the INSTALL file
- License is in the LICENSE file
