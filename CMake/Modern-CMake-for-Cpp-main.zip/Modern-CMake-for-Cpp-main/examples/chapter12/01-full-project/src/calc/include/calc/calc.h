#pragma once

namespace Calc {
int Sum(int a, int b);
int Multiply(int a, int b);
}  // namespace Calc
