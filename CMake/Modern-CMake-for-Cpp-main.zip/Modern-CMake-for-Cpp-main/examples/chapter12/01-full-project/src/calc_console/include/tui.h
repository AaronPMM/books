#include <ftxui/component/component.hpp>
ftxui::Component getTui();
