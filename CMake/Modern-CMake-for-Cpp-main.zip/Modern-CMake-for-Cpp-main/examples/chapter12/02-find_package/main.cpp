#include "calc/calc.h"
#include <iostream>

int main(int argc, char** argv) {
  std::cout << Calc::Sum(2, 2) << std::endl;
}
