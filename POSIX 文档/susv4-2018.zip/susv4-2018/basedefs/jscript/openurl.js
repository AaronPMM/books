function openurl (text) 
{
var url=text;
remote = window.open(text,"",'toolbar=no,directories=no,menubar=no,status=no,scrollbars=yes,resizable=yes,width=300,height=480,alwaysRaised=yes');
}
